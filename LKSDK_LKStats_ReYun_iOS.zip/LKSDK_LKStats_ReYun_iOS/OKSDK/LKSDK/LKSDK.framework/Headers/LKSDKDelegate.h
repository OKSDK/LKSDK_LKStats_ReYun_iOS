//
//  OKSDKDelegate.h
//  LKPlatformSDK
//
//  Created by 刘东鑫 on 15/7/6.
//  Copyright (c) 2015年 LineKong. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol LKSDKDelegate <NSObject>
@required
/*!
 *  @author Liudx
 *
 *  @brief  初始化成功回调
 *
 *  @param result 初始化成功回调结果
 */
-(void)LKinitSuccessWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  初始化失败回调
 *
 *  @param result 失败回调消息
 */
-(void)LKinitFalied;

/*!
 *  @author Liudx
 *
 *  @brief  登录成功回调
 *
 *  @param result 登录成功回调消息
 */
-(void)LKloginSuccessWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  登录失败回调
 *
 *  @param result 登录失败回调消息
 */
-(void)LKloginFailedWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  切换账号回调
 *
 *  @param result 切换账号回调消息
 */
-(void)LKswitchAccountWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  登录取消回调
 *
 *  @param result 登录取消回调信息
 */
-(void)LKLoginCancel;
/*!
 *  @author Liudx
 *
 *  @brief  登出成功回调
 *
 *  @param result 登出成功回调消息
 */
-(void)LKlogoutSuccessWithResult:(NSString *)result;
/**
 *  绑定手机回调
 *
 *  @param userName
 */
- (void)LKBindPhoneWithUserName:(NSString *)userName;
/**
 *  绑定账号回调
 *
 *  @param userName
 */
- (void)LKBindAccountWithUserName:(NSString *)userName;
@end

