//
//  AppDelegate.h
//  SDKDemo
//
//  Created by Madoka on 17/5/4.
//  Copyright © 2017年 Madoka. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

